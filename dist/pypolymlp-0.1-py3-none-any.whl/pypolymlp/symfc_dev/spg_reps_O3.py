#!/usr/bin/env python
import numpy as np
from scipy.sparse import coo_array, kron

from phonopy.structure.atoms import PhonopyAtoms
from symfc.spg_reps import SpgReps

class SpgRepsO3(SpgReps):
    """Class of reps of space group operations for fc3."""

    def __init__(self, supercell: PhonopyAtoms):
        """Init method.

        Parameters
        ----------
        supercell : PhonopyAtoms
            Supercell.

        """
        self._r3_reps: list[coo_array]
        self._col: np.ndarray
        self._data: np.ndarray
        super().__init__(supercell)

    @property
    def r_reps(self) -> list[coo_array]:
        """Return 3rd rank tensor rotation matricies."""
        return self._r3_reps

    def get_sigma3_rep(self, i: int) -> coo_array:
        """Compute and return i-th atomic pair permutation matrix.

        Parameters
        ----------
        i : int
            Index of coset presentations of space group operations.

        """
        data, row, col, shape = self._get_sigma3_rep_data(i)
        return coo_array((data, (row, col)), shape=shape)

    def _prepare(self):
        rotations = super()._prepare()
        N = len(self._numbers)
        a = np.arange(N)
        self._atom_triplets = np.stack(np.meshgrid(a,a,a), axis=-1).reshape(-1, 3)
        self._coeff = np.array([1, N, N**2], dtype=int)
        self._col = self._atom_triplets @ self._coeff
        self._data = np.ones(N * N * N, dtype=int)
        self._compute_r3_reps(rotations)

    def _compute_r3_reps(self, rotations: np.ndarray, tol: float = 1e-10):
        """Compute and return 3rd rank tensor rotation matricies."""
        uri = self._unique_rotation_indices
        r3_reps = []
        for r in rotations[uri]:
            r_c = self._lattice.T @ r @ np.linalg.inv(self._lattice.T)
            r3_rep = np.kron(r_c, np.kron(r_c, r_c))
            row, col = np.nonzero(np.abs(r3_rep) > tol)
            data = r3_rep[(row, col)]
            r3_reps.append(coo_array((data, (row, col)), shape=r3_rep.shape))
        self._r3_reps = r3_reps

    def _get_sigma3_rep_data(self, i: int) -> coo_array:
        uri = self._unique_rotation_indices
        permutation = self._permutations[uri[i]]
        NNN = len(self._numbers) ** 3
        row = permutation[self._atom_triplets] @ self._coeff
        return self._data, row, self._col, (NNN, NNN)

